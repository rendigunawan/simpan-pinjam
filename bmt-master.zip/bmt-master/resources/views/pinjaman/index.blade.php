@extends('layouts.app', ['linkpinjaman'=>'active'])

@section('content')
<pinjaman-list></pinjaman-list>
@endsection
