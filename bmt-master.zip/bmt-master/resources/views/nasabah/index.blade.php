@extends('layouts.app', ['linknasabah'=>'active'])

@section('content')
<nasabah-list></nasabah-list>
@endsection
