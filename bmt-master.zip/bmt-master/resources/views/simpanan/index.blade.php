@extends('layouts.app', ['linksimpanan'=>'active'])

@section('content')
<simpanan-list></simpanan-list>
@endsection
