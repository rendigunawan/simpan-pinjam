@extends('layouts.app', ['linkpenarikan'=>'active'])

@section('content')
<penarikan-list></penarikan-list>
@endsection
